﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NikeSearch
{
    class Program
    {
        public static string currentNikeJson= "itemsNike.json";
        public static string currentAllegroJson = "items.json";
        public class ProduktOb
        {
            public Object url { get; set; }
            public Object price { get; set; }
            public Object image { get; set; }
            public Object title { get; set; }
        }
        public static List<string> InvalidJsonElements;

        public static IList<T> DeserializeToList<T>(string jsonString)
        {
            InvalidJsonElements = null;
            var array = JArray.Parse(jsonString);
            IList<T> objectsList = new List<T>();

            foreach (var item in array)
            {
                objectsList.Add(item.ToObject<T>());
            }

            return objectsList;
        }
        public static IList<ProduktOb> Deserialize(string path)
        {
            using (StreamReader r = new StreamReader(System.IO.Path.GetFullPath(path)))
            {
                string json = r.ReadToEnd();
                ProduktOb productObj = new ProduktOb();
                IList<ProduktOb> validProdcuts;
                validProdcuts = JsonConvert.DeserializeObject<IList<ProduktOb>>(json);
                return validProdcuts;
            }
        }
    }
    public class Produkt
    {
        public string url { get; set; }
        public string price { get; set; }
        public string image { get; set; }
        public string title { get; set; }
        public Produkt(string url, string price, string image, string title)
        {
            this.url = url;
            this.price = price;
            this.image = image;
            this.title = title;
        }
    }

    public class ProduktyAllegro : ObservableCollection<Produkt>
    {
        public ProduktyAllegro()
        {
            IList<Program.ProduktOb> produkty = Program.Deserialize(Program.currentAllegroJson);
            foreach (var produkt in produkty)
            {
                Add(new Produkt(produkt.url.ToString().Split('"')[1], produkt.price.ToString().Split('"')[1], produkt.image.ToString().Split('"')[1], 
                    produkt.title.ToString().Split('"')[1]));
            }

        }
    }
    public class ProduktyNike : ObservableCollection<Produkt>
    {
        public ProduktyNike()
        {
            IList<Program.ProduktOb> produkty = Program.Deserialize(Program.currentNikeJson);
            foreach (var produkt in produkty)
            {
                string cenastr = produkt.price.ToString().Split(';')[1].Replace(".",",");
                double cena = 5.58 * Convert.ToDouble(cenastr);
                cenastr=Math.Round(cena,2).ToString();
                Add(new Produkt(produkt.url.ToString(), cenastr, produkt.image.ToString(), produkt.title.ToString()));
            }

        }
    }
}
