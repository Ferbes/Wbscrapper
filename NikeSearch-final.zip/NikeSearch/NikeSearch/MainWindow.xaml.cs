﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NikeSearch
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            listBox_Copy.ItemsSource = new ProduktyNike();
            listBox.Items.Filter = delegate (object obj)
            {
                Produkt pr = (Produkt)obj;
                string str = pr.title.ToString();
                if (String.IsNullOrEmpty(str)) return false;
                int index = str.IndexOf(comparer, StringComparison.CurrentCultureIgnoreCase);
                return (index > -1);
            };
        }
        Produkt pa;
        string comparer = "!@#$%^&*()";
        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            label.Content = "";
            label.Visibility = System.Windows.Visibility.Hidden;
            label1.Content = "";
            label1.Visibility = System.Windows.Visibility.Hidden;
            textBlock.Visibility = System.Windows.Visibility.Hidden;
            wrapPanel1.Children.Clear();
            if (listBox.SelectedIndex != -1)
            {
                pa = (Produkt)e.AddedItems[0];
                var image = new Image();
                var fullFilePath = pa.image;
                Console.Write(fullFilePath);
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(fullFilePath, UriKind.Absolute);
                bitmap.EndInit();
                image.Source = bitmap;
                wrapPanel1.Children.Clear();
                wrapPanel1.Children.Add(image);
                wrapPanel1.UpdateLayout();
                label.Content = pa.title;
                label.Visibility = System.Windows.Visibility.Visible;
                label1.Content = "Cena: " + pa.price + " zł";
                label1.Visibility = System.Windows.Visibility.Visible;
                Uri myUri = new Uri(pa.url);
                hyperLink.NavigateUri = myUri;
                textBlock.Visibility = System.Windows.Visibility.Visible;
            }
        }
        private void listBox_Copy_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            comparer = "!@#$%^&*()";
            listBox.Items.Filter = delegate (object obj)
            {
                Produkt pr = (Produkt)obj;
                string str = pr.title.ToString();
                if (String.IsNullOrEmpty(str)) return false;
                int index = str.IndexOf(comparer, StringComparison.CurrentCultureIgnoreCase);
                return (index > -1);
            };
            label_Copy.Content = "";
            label_Copy.Visibility = System.Windows.Visibility.Hidden;
            label1_Copy.Content = "";
            label1_Copy.Visibility = System.Windows.Visibility.Hidden;
            textBlock_Copy.Visibility = System.Windows.Visibility.Hidden;
            wrapPanel1_Copy.Children.Clear();
            listBox.UnselectAll();
            if (listBox_Copy.SelectedIndex != -1)
            {
                pa = (Produkt)e.AddedItems[0];
                var image = new Image();
                var fullFilePath = pa.image;
                Console.Write(fullFilePath);
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(fullFilePath, UriKind.Absolute);
                bitmap.EndInit();
                image.Source = bitmap;
                wrapPanel1_Copy.Children.Clear();
                wrapPanel1_Copy.Children.Add(image);
                wrapPanel1_Copy.UpdateLayout();
                label_Copy.Content = pa.title;
                label_Copy.Visibility = System.Windows.Visibility.Visible;
                label1_Copy.Content = "Cena: " + pa.price + " zł";
                label1_Copy.Visibility = System.Windows.Visibility.Visible;
                Uri myUri = new Uri(pa.url);
                hyperLink_Copy.NavigateUri = myUri;
                textBlock_Copy.Visibility = System.Windows.Visibility.Visible;
                comparer = pa.title;
                Console.WriteLine("l.elem.:"+listBox.Items.Count);
                while (listBox.Items.Count==0 && comparer!="Nike "&&comparer!="Nike" && comparer!="Hurley")
                {
                    Console.WriteLine("zero elementow");
                    listBox.Items.Filter = delegate (object obj)
                    {
                        Produkt pr = (Produkt)obj;
                        string str = pr.title.ToString();
                        if (String.IsNullOrEmpty(str)) return false;
                        int index = str.IndexOf(comparer, StringComparison.CurrentCultureIgnoreCase);
                        return (index > -1);
                    };
                    comparer = comparer.Remove(comparer.Length - 1);
                    Console.WriteLine(comparer);
                }
            }

            listBox.Items.Filter = delegate (object obj)
            {
                Produkt pr = (Produkt)obj;
                string str = pr.title.ToString();
                if (String.IsNullOrEmpty(str)) return false;
                int index = str.IndexOf(comparer, StringComparison.CurrentCultureIgnoreCase);
                return (index > -1);
            };
        }
        public void DoubleClickHandler(object sender, MouseEventArgs e)
        {
            
        }
        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
            e.Handled = true;
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            listBox.UnselectAll();
            listBox_Copy.UnselectAll();           
            listBox_Copy.Items.Filter = delegate (object obj)
             {
                 Produkt pr = (Produkt)obj;
                 string str = pr.title.ToString();
                 if (String.IsNullOrEmpty(str)) return false;
                 int index = str.IndexOf(textBox.Text, StringComparison.CurrentCultureIgnoreCase);
                 return (index > -1);
             };
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog 
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();



            // Set filter for file extension and default file extension 
            dlg.DefaultExt = ".png";
            dlg.Filter = "JSON Files (*.json)|*.json";


            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog();


            // Get the selected file name and display in a TextBox 
            if (result == true)
            {
                // Open document 
                string filename = dlg.FileName;
                if (radioButton.IsChecked == true)
                {
                    Console.WriteLine("JUST DO IT.");
                    Program.currentNikeJson = filename;
                    listBox_Copy.ItemsSource = new ProduktyNike();
                }
                else
                {
                    Program.currentAllegroJson = filename;
                    listBox.ItemsSource = new ProduktyAllegro();
                }

            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            string commandAllegro = "cd "+System.IO.Path.GetFullPath(@"Webscrapper\Allegro\allegro\allegro\spiders") + " & scrapy runspider AllegroSpider.py -o allegro[" + DateTime.Now.ToString().Replace(".", "").Replace(" ", "_").Replace(":", "-") + "].json";
            string commandNike = "cd " + System.IO.Path.GetFullPath(@"Webscrapper\NikeScroll\Nike\spiders") + " & scrapy crawl NikeSpiderScroll -o nike[" + DateTime.Now.ToString().Replace(".", "").Replace(" ", "_").Replace(":", "-") + "].json";
            //Console.Write(command);
            //System.Diagnostics.Process.Start("CMD.exe", command).StartInfo;
            try
            {
                // create the ProcessStartInfo using "cmd" as the program to be run,
                // and "/c " as the parameters.
                // Incidentally, /c tells cmd that we want it to execute the command that follows,
                // and then exit.
                System.Diagnostics.ProcessStartInfo procStartInfo;
                if (radioButton.IsChecked == true)
                 procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + commandNike);
                else
                 procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + commandAllegro);

                // The following commands are needed to redirect the standard output.
                // This means that it will be redirected to the Process.StandardOutput StreamReader.
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                // Do not create the black window.
                // Now we create a process, assign its ProcessStartInfo and start it
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                // Get the output into a string
                string result = proc.StandardOutput.ReadToEnd();
                // Display the command output.
                Console.WriteLine(result);
            }
            catch (Exception objException)
            {
                // Log the exception
            }
        }
    }
}
